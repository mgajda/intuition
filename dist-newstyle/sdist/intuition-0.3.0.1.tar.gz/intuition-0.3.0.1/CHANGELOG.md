# Revision history for intuition

## 0.3.0.1 -- 2025-06-20

* Added .cabal and stack.yaml files to make it build.

## 0.3.0.0 -- 2025-06-18

* First version shared by Alx.
